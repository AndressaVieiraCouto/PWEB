var tam = 45;
var idade = Array(tam);
var sexo = Array(tam);
var opiniao = Array(tam);
var somaIdade = 0;
var maisVelho = 0;
var maisNovo = 100000;
var qtdeNotaPessimo = 0;
var qtdeNotaBomOtimo = 0;
var qtdeMulherTotal = 0;
var qtdeHomemTotal = 0;

for(i = 0; i < tam; i++){
    idade[i] =parseFloat(prompt("Digite sua idade: "));
    sexo[i] = prompt("Digite seu sexo F(Feminino) ou M(Masculino) : ");
    opiniao[i] = prompt("Digite sua Opinião: 1(Péssimo), 2(Regular), 3(Bom), 4(Ótimo): ");
}

for(i = 0; i < tam; i++){
    if(idade[i] > maisVelho){
        maisVelho = idade[i];
    }
    if(idade[i] < maisNovo){
        maisNovo = idade[i];
    }
    somaIdade += idade[i];

    if(opiniao[i] == 1){
        qtdeNotaPessimo++;
    }

    if((opiniao[i] == 3) || (opiniao[i] == 4)){
        qtdeNotaBomOtimo++;
    }

    if((sexo[i] == "f") || (sexo[i] == "F")){
        qtdeMulher++;
    }

    if((sexo[i] == "m") || (sexo[i] == "M")){
        qtdeHomem++;
    }
}
alert("Media das idades = " + (somaIdade/tam));
alert("Mais Velha = " + maisVelho);
alert("Mais Novo = " + maisNovo);
alert("Quantidade de Péssimo = " + qtdeNotaPessimo);
alert("porcentagem de Bom e Ótimo = " + ((qtdeNotaBomOtimo/tam) * 100) + "%" );
alert("Quantidade de Mulheres = " + qtdeMulher);
alert("Quantidade de Homens = " + qtdeHomem);