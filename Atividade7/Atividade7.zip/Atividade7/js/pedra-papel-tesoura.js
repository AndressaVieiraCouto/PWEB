const numeroAleatorio = Math.random(0, 0.99).toFixed(2);

let escolhaDoComputador;

if (numeroAleatorio > 0.66) {
    escolhaDoComputador = 'Pedra';
} else if (numeroAleatorio > 0.33) {
    escolhaDoComputador = 'Papel';
}else escolhaDoComputador = 'Tesoura';

/**
 * Easy Mode
 * Descomente a linha abaixo para nunca mais perder =D
 */
// alert(`Computador diz: \nEu escolhi ${escolhaDoComputador}`);

let valido = false;

do {
    var valorDigitado = prompt('Escolha sua opção: \nDigite 1 para Pedra \nou \nDigite 2 para Papel \nou \nDigite 3 para Tesoura ');
    if (valorDigitado === '1' || valorDigitado === '2' || valorDigitado === '3') {
        valido = true;
    }
}
while ( valido != true );

escolhaDoUsuario = 'Pedra';

switch(valorDigitado) {
    case '1':
        escolhaDoUsuario = 'Pedra';
    break;
    case '2':
        escolhaDoUsuario = 'Papel';
    break;
    case '3':
        escolhaDoUsuario = 'Tesoura';
    break;
    default:
    break;
}

var vencedor;

do {
    if ( escolhaDoComputador === escolhaDoUsuario) {
        vencedor = 'Deu empate!';
        break;
    }
    
    if ( escolhaDoComputador === 'Papel' && escolhaDoUsuario === 'Pedra') {
        vencedor = 'Computador'+ '\nPapel cobre a Pedra.';
        break;
    } 

    if ( escolhaDoComputador === 'Pedra' && escolhaDoUsuario === 'Papel') {
        vencedor = 'Você' + '\nPapel cobre a Pedra.';
        break;
    }

    if ( escolhaDoComputador === 'Papel' && escolhaDoUsuario === 'Tesoura') {
        vencedor = 'Você' + '\nTesoura corta o papel.';
        break;
    } 

    if ( escolhaDoComputador === 'Tesoura' && escolhaDoUsuario === 'Papel') {
        vencedor = 'Computador' + '\nTesoura corta o Papel.';
        break;
    }

    if ( escolhaDoComputador === 'Pedra' && escolhaDoUsuario === 'Tesoura') {
        vencedor = 'Computador' + '\nPedra quebra a Tesoura.';
        break;
    }else {
        vencedor = 'Você' + '\nPedra quebra a Tesoura.'; // Usuário = Tesoura e você = Pedra
        break;
    }

    
} while ( vencedor != undefined );

alert(`A escolha do computador foi: \n${escolhaDoComputador}\n\nA sua escolhe foi: \n${escolhaDoUsuario}\n\nVencedor: ${vencedor}`);

if (vencedor === 'Você') {
    alert('Parabéns pela vitória!');
}
